DW-FSE v1.81 and ss-MGOT v1.911 upload candidates

STATUS: source-validated candidates; NOT vendor-compiled or scanner-verified.

Nothing in this package has been compiled with the MR Solutions PPLC/Forth toolchain or run on the
scanner. All timing, b-value, signal and compiler statements are predictions from the repository's
source-level mapper and models. Start with SCANNER_TEST_PLAN.md (Items 1 and 2 are blocking).

CONTENTS
  sequences/FSE_dwi_CPMG_non_CPMG_twoTE-1.81.ppl    DW-FSE v1.81 (from v1.8)
  sequences/FSE_dwi_CPMG_non_CPMG_twoTE-1.81.ppr    matching protocol (acquired test1e protocol; :PPL line changed)
  sequences/FSE_dwi_CPMG_non_CPMG_twoTE-1.911.ppl   ss-MGOT v1.911 (from the uploaded method-only v7 build)
  sequences/FSE_dwi_CPMG_non_CPMG_twoTE-1.911.ppr   matching protocol (v7 PPR, esp 13, 64-row tables)
  rf/v19_*.seq (6 files)                             RF libraries referenced by v1.911 ONLY
  FINAL_REPORT.md                                    before/after report, evidence status, limits
  ERROR_CODES.md                                     v1.81 messages and v1.911 error codes (E140-E146 new)
  SCANNER_TEST_PLAN.md                               prioritized scanner tests with pass/fail criteria
  README.md                                          this file

SHA-256 of the four sequence files
  545a14ec8c65ed578ea76628796547dd463eb8cd4a2efa680de89058a837de69  FSE_dwi_CPMG_non_CPMG_twoTE-1.81.ppl
  ad82112ddfc7389a58caea6598cb5eb7583a271e71e62cd8c006190c52cdb159  FSE_dwi_CPMG_non_CPMG_twoTE-1.81.ppr
  716478bb357ba1479e6cc8fcc18c1085e44b3c78ecf1bdf32bb561b171838682  FSE_dwi_CPMG_non_CPMG_twoTE-1.911.ppl
  b2976e7464367a7aa6b6b8e04765cc04a3fd85c0d2ec64c9c9a57963bf9635c2  FSE_dwi_CPMG_non_CPMG_twoTE-1.911.ppr
Hashes of every file and of this ZIP are in dist/SHA256SUMS.txt (outside the ZIP).

RF LIBRARIES AND INCLUDES
  v1.911 loads six libraries from g:\J_Figger\seqlib\ (v19_slrprep90, v19_slrprep180, v19_slrtip90,
  v19_slrelim90, v19_reexc90, v19_imaging180). They are byte-identical to the libraries of the last
  uploaded method-only v7 package (and to scanner/rf/ in the repository). If they are already installed,
  verify the hashes and do not overwrite; otherwise copy them as NEW files and open each in WavEd.
  v1.81 uses only stock c:\smis\seqlib libraries. Both PPLs use the vendor includes already used by
  v1.8 and v1.91 (stdfn_15.pph, var_20.pph, offst_20.pph, m3040_15.pph, m3031_15.pph, tstex_15.pph and
  g3040_15.seq); they are not redistributed here.

NOTES
  - Keep original filenames (remove download suffixes such as " (1)"); enter full paths without quotes.
  - The v1.81 PPR names G:\J_Figger\FSE_dwi_CPMG_non_CPMG_twoTE-1.81.ppl; the v1.911 PPR names the bare filename.
  - v1.81 and v1.911 do not replace v1.8, v1.91 or v1.92. Keep those as controls.
  - v1.911 runs only ESP 13 and unrotated geometry (E144, E146); the train crusher must stay at -8223
    unless you accept lattice values (E142). See ERROR_CODES.md.
  - Effective b of v1.81 differs from v1.8 for the same nominal b (see FINAL_REPORT.md section 8).
    Do not pool v1.8 and v1.81 data by nominal b.
  - The v1.911 finite-RF strict gate failed at B0 = +/-128 Hz and was accepted as a documented
    deviation (FINAL_REPORT.md section 9); confirm with the off-resonance test.
